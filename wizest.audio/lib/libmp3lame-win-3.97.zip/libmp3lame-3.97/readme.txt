This is a pre-built DLL of libmp3lame from the
lame-3.97 distribution.

This version was built with Visual Studio 2003
and exports all of the functions listed in lame.h.

To build, replace the lame-3.97\Dll\BladeMP3EncDLL.def
with the one in this archive and build with VS.
